@echo off
setlocal
TITLE jDroid-X-Desk Native Launcher
cd /d "%~dp0.."

echo ========================================================
echo   jDroid-X-Desk Pure Native Windows Machine Console
echo ========================================================
echo.

set REBUILD_NEEDED=0

if "%1"=="/rebuild" set REBUILD_NEEDED=1
if "%1"=="/compile" set REBUILD_NEEDED=1

if not exist "jDroid-X-Desk.exe" (
    set REBUILD_NEEDED=1
)

if "%REBUILD_NEEDED%"=="1" (
    echo [INFO] Compiling modular native solution from Native/ directory...
    call compile_native.bat
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Native compilation failed.
        pause
        exit /b 1
    )
    echo [PASS] Compiled jDroid-X-Desk.exe successfully!
)

echo [PASS] Launching jDroid-X-Desk inside trusted Windows CLR host...
start "" powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -Command "$p=(Resolve-Path 'jDroid-X-Desk.exe').Path; [System.Reflection.Assembly]::Load([System.IO.File]::ReadAllBytes($p)).EntryPoint.Invoke($null, @([string[]]@()))"
exit /b 0
