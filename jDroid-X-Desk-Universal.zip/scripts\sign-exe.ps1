param(
    [string]$TargetExe = "jDroid-X-Desk.exe",
    [switch]$Force
)

$thumbprint = "ACBD12BEE072C0CAE42760AF078BD1996A6F293F"

# Check if the Enterprise Root is trusted by Windows Kernel (LocalMachine\Root)
$isMachineRootTrusted = [bool](Get-ChildItem Cert:\LocalMachine\Root -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $thumbprint })

if (-not $isMachineRootTrusted -and -not $Force) {
    Write-Host "[NOTICE] Enterprise Root certificate is not in Cert:\LocalMachine\Root." -ForegroundColor Yellow
    Write-Host "[NOTICE] Under Windows 11 Smart App Control (SAC), signing with an un-whitelisted private certificate triggers Event ID 3077 (Device Guard Block)." -ForegroundColor Yellow
    Write-Host "[NOTICE] Leaving binary unsigned so it runs cleanly without Device Guard blocking." -ForegroundColor Green
    Write-Host "[ACTION] To sign with full kernel trust, run 'TRUST_ENTERPRISE_CERT_AS_ADMIN.bat' as Administrator once." -ForegroundColor Cyan
    exit 0
}

Write-Host "=== Step 1: Whitelist in Trusted Publisher Store ===" -ForegroundColor Cyan
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$rootDir = Split-Path -Parent $scriptDir
$cerPath = Join-Path $rootDir "jDroid-X-Enterprise.cer"
if (Test-Path $cerPath) {
    & certutil -user -addstore TrustedPublisher $cerPath | Out-Null
    Write-Host "[+] Registered in CurrentUser\TrustedPublisher" -ForegroundColor Green
}

Write-Host "`n=== Step 2: Sign Binary with Authenticode ===" -ForegroundColor Cyan
$cert = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.Thumbprint -eq $thumbprint -and $_.HasPrivateKey }
if (-not $cert) {
    $cert = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.Subject -like "*jDroid-X Studio Enterprise*" -and $_.HasPrivateKey } | Select-Object -First 1
}

if (-not $cert) {
    Write-Error "Code-signing certificate not found in Cert:\CurrentUser\My!"
    exit 1
}

Write-Host "[+] Signer: $($cert.Subject)"
$sig = Set-AuthenticodeSignature -FilePath $TargetExe -Certificate $cert

Write-Host "`n=== Step 3: Microsoft Authenticode Verification ===" -ForegroundColor Cyan
$auth = Get-AuthenticodeSignature -FilePath $TargetExe
$auth | Format-List Path, Status, StatusMessage, SignerCertificate

if ($auth.Status -eq "Valid") {
    Write-Host "[SUCCESS] Authenticode Status: VALID (Full System Trust & Zero Smart App Control blocks)!" -ForegroundColor Green
    exit 0
} elseif ($auth.SignerCertificate -and $auth.SignerCertificate.Thumbprint -eq $thumbprint) {
    Write-Host "[NOTICE] Binary signed with Enterprise Certificate ($thumbprint), but Status is '$($auth.Status)'." -ForegroundColor Yellow
    Write-Host "[ACTION] To whitelist permanently on this machine, run 'TRUST_ENTERPRISE_CERT_AS_ADMIN.bat' as Administrator once." -ForegroundColor Yellow
    exit 0
} else {
    Write-Warning "[WARN] Signing did not match expected thumbprint."
    exit 1
}
